-- IbizaRP Context Menu
-- Made By Nedzyu

local PANEL = {}
local blur = Material("pp/blurscreen")
local frameColor = Color(211, 188, 141, 230)
local yellowColor = Color(255, 255, 0, 255)
local tanColor = Color(211, 188, 141, 255)
local greenColor = Color(100, 200, 100, 255)
local menuWidth = ScrW() * 0.2
local menuHeight = ScrH() * 0.7

-- Informations joueur
local playerInfo = {
    name = "",
    steamID = "",
    money = 0
}

-- Polices personnalis�es plus accrocheuses
surface.CreateFont("IbizaTitle", {
    font = "Impact",
    size = 32,
    weight = 800,
    antialias = true,
    shadow = true
})

surface.CreateFont("IbizaSubTitle", {
    font = "Arial",
    size = 22,
    weight = 700,
    antialias = true,
    shadow = true
})

surface.CreateFont("IbizaText", {
    font = "Tahoma",
    size = 18,
    weight = 500,
    antialias = true
})

-- D�finitions des boutons avec des ic�nes am�lior�es
local menuButtons = {
    {name = "Lacher l'argent", icon = "icon16/money_dollar.png", desc = "Donner de l'argent", func = function() 
        Derma_StringRequest("Donner de l'argent", "Montant � donner:", "100", function(text) 
            RunConsoleCommand("darkrp", "dropmoney", text) 
        end)
    end},
    
    {name = "Lacher l'arme", icon = "icon16/bomb.png", desc = "Lacher son arme", func = function() 
        RunConsoleCommand("darkrp", "dropweapon") 
    end},
    
    {name = "Appeler un Admin", icon = "icon16/user_red.png", desc = "Support admin", func = function() 
        Derma_StringRequest("Call Admin", "D�crivez votre probl�me:", "", function(text) 
            RunConsoleCommand("admin_request", text) 
        end)
    end},
    
    {name = "3eme Personne", icon = "icon16/camera_edit.png", desc = "Vue 3eme personne", func = function() 
        RunConsoleCommand("simple_thirdperson_enable_toggle") 
    end},
    
    {name = "Changer de Nom", icon = "icon16/user_edit.png", desc = "Changer de nom RP", func = function() 
        Derma_StringRequest("Change RP Name", "Nouveau nom RP:", LocalPlayer():Nick(), function(text) 
            RunConsoleCommand("darkrp", "rpname", text) 
        end)
    end}
}

-- Liens communautaires
local communityLinks = {
    {name = "Discord", url = "https://discord.gg/Jv6b7sa5hm", icon = "icon16/world_link.png"},
    {name = "Steam Workshop", url = "https://steamcommunity.com/sharedfiles/filedetails/?id=2086767715", icon = "icon16/rainbow.png"}
}

-- Mat�riaux personnalis�s pour des ic�nes plus stylis�es
local customIcons = {
    money = Material("icon16/money_dollar.png"),
    weapon = Material("icon16/bomb.png"),
    admin = Material("icon16/user_red.png"),
    thirdperson = Material("icon16/camera_edit.png"),
    rpname = Material("icon16/user_edit.png")
}

function PANEL:Init()
    self:SetSize(menuWidth, menuHeight)
    self:SetPos(ScrW() - menuWidth - 10, (ScrH() - menuHeight) / 2) -- Positionnement � droite
    self:SetTitle("")
    self:ShowCloseButton(false)
    self:SetDraggable(false)
    
    -- Mise � jour des informations joueur
    playerInfo.name = LocalPlayer():Nick() or "Unknown"
    playerInfo.steamID = LocalPlayer():SteamID() or "STEAM_0:0:0"
    playerInfo.money = LocalPlayer():getDarkRPVar("money") or 0
    
    -- Cr�ation des panels
    self:CreateHeader()
    self:CreatePlayerInfo()
    self:CreateButtons()
    self:CreateCommunityPanel()
    self:CreateFooter()
    
    -- Bouton de fermeture
    local closeBtn = vgui.Create("DButton", self)
    closeBtn:SetSize(40, 40)
    closeBtn:SetPos(menuWidth - 50, 10)
    closeBtn:SetText("X")
    closeBtn:SetFont("IbizaSubTitle")
    closeBtn:SetTextColor(Color(255, 255, 255))
    closeBtn.Paint = function(s, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(200, 80, 80, 200))
        
        if s:IsHovered() then
            draw.RoundedBox(8, 2, 2, w-4, h-4, Color(230, 100, 100, 200))
        end
    end
    closeBtn.DoClick = function()
        self:Close()
    end
end

function PANEL:CreateHeader()
    local header = vgui.Create("DPanel", self)
    header:SetSize(menuWidth - 20, 70)
    header:SetPos(10, 10)
    header.Paint = function(s, w, h)
        -- Fond stylis� avec d�grad�
        surface.SetDrawColor(45, 45, 45, 230)
        surface.DrawRect(0, 0, w, h)
        
        surface.SetDrawColor(60, 60, 60, 200)
        surface.DrawRect(0, 0, w, h/2)
        
        draw.RoundedBox(8, 0, 0, w, h, Color(45, 45, 45, 0))
        
        -- Texte avec effet ombre
        draw.SimpleText("IBIZA", "IbizaTitle", w/2 - 40, h/2, yellowColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText("ROLEPLAY", "IbizaTitle", w/2 + 40, h/2, tanColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        
        -- Effet de brillance
        surface.SetDrawColor(255, 255, 255, math.abs(math.sin(CurTime() * 1.5) * 50))
        surface.DrawRect(0, h/2 - 2, w, 4)
    end
end

function PANEL:CreatePlayerInfo()
    local infoPanel = vgui.Create("DPanel", self)
    infoPanel:SetSize(menuWidth - 20, 90)
    infoPanel:SetPos(10, 90)
    infoPanel.Paint = function(s, w, h)
        -- Fond stylis�
        draw.RoundedBox(8, 0, 0, w, h, Color(60, 60, 60, 200))
        
        -- Bordure brillante
        surface.SetDrawColor(100, 100, 100, 150)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        
        -- Informations joueur avec police am�lior�e
        draw.SimpleText("Nom: " .. playerInfo.name, "IbizaText", 10, 15, Color(255, 255, 255), TEXT_ALIGN_LEFT)
        draw.SimpleText("SteamID: " .. playerInfo.steamID, "IbizaText", 10, 40, Color(200, 200, 200), TEXT_ALIGN_LEFT)
        draw.SimpleText("Argent: $" .. playerInfo.money, "IbizaText", 10, 65, Color(150, 255, 150), TEXT_ALIGN_LEFT)
    end
end

function PANEL:CreateButtons()
    local buttonPanel = vgui.Create("DScrollPanel", self)
    buttonPanel:SetSize(menuWidth - 20, menuHeight - 270)
    buttonPanel:SetPos(10, 190)
    
    -- Style du scroll
    local scrollBar = buttonPanel:GetVBar()
    scrollBar:SetWide(8)
    function scrollBar:Paint(w, h) draw.RoundedBox(0, 0, 0, w, h, Color(60, 60, 60, 100)) end
    function scrollBar.btnUp:Paint(w, h) draw.RoundedBox(4, 0, 0, w, h, Color(100, 100, 100)) end
    function scrollBar.btnDown:Paint(w, h) draw.RoundedBox(4, 0, 0, w, h, Color(100, 100, 100)) end
    function scrollBar.btnGrip:Paint(w, h) draw.RoundedBox(4, 0, 0, w, h, Color(yellowColor.r, yellowColor.g, yellowColor.b, 150)) end
    
    local yPos = 0
    for k, v in pairs(menuButtons) do
        local button = vgui.Create("DButton", buttonPanel)
        button:SetSize(menuWidth - 40, 50)
        button:SetPos(10, yPos)
        button:SetText("")
        
        button.Paint = function(s, w, h)
            local bgColor = s:IsHovered() and Color(100, 180, 100, 200) or Color(80, 80, 80, 200)
            draw.RoundedBox(8, 0, 0, w, h, bgColor)
            
            -- Effet de surbrillance au survol
            if s:IsHovered() then
                surface.SetDrawColor(yellowColor)
                surface.DrawOutlinedRect(0, 0, w, h, 2)
                
                -- D�grad� au survol
                for i=0, h do
                    local alpha = 150 - i/h * 150
                    surface.SetDrawColor(255, 255, 255, alpha)
                    surface.DrawLine(0, i, w, i)
                end
            end
            
            -- Ic�ne plus grande
            surface.SetDrawColor(255, 255, 255, 255)
            surface.SetMaterial(Material(v.icon))
            surface.DrawTexturedRect(10, h/2 - 8, 16, 16)
            
            -- Texte avec police stylis�e
            draw.SimpleText(v.name, "IbizaSubTitle", 36, h/2 - 10, Color(255, 255, 255), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(v.desc, "IbizaText", 36, h/2 + 10, Color(200, 200, 200), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end
        
        button.DoClick = v.func
        
        yPos = yPos + 60
    end
end

function PANEL:CreateCommunityPanel()
    local commPanel = vgui.Create("DPanel", self)
    commPanel:SetSize(menuWidth - 20, 90)
    commPanel:SetPos(10, menuHeight - 170)
    commPanel.Paint = function(s, w, h)
        -- Fond stylis�
        draw.RoundedBox(8, 0, 0, w, h, Color(60, 60, 60, 200))
        
        -- Titre avec effet ombre
        draw.SimpleText("LIENS", "IbizaSubTitle", w/2, 15, Color(255, 255, 100), TEXT_ALIGN_CENTER)
        
        -- Ligne de s�paration avec effet
        surface.SetDrawColor(yellowColor.r, yellowColor.g, yellowColor.b, 100)
        surface.DrawRect(20, 35, w-40, 2)
    end
    
    local xPos = 20
    for k, v in pairs(communityLinks) do
        local button = vgui.Create("DButton", commPanel)
        button:SetSize(menuWidth/2 - 30, 35)
        button:SetPos(xPos, 45)
        button:SetText(v.name)
        button:SetFont("IbizaText")
        button:SetTextColor(Color(255, 255, 255))
        button:SetIcon(v.icon)
        
        button.Paint = function(s, w, h)
            local bgColor = s:IsHovered() and Color(100, 100, 180, 200) or Color(80, 80, 80, 200)
            draw.RoundedBox(6, 0, 0, w, h, bgColor)
            
            if s:IsHovered() then
                -- Effet de lueur au survol
                surface.SetDrawColor(120, 120, 255, 50)
                surface.DrawRect(0, 0, w, h)
            end
        end
        
        button.DoClick = function()
            gui.OpenURL(v.url)
        end
        
        xPos = xPos + menuWidth/2 - 20
    end
end

function PANEL:CreateFooter()
    local footer = vgui.Create("DPanel", self)
    footer:SetSize(menuWidth - 20, 50)
    footer:SetPos(10, menuHeight - 70)
    footer.Paint = function(s, w, h)
        draw.RoundedBox(8, 0, 0, w, h, Color(45, 45, 45, 200))
        
        -- Texte avec effet
        local textColor = Color(200, 200, 200)
        textColor.a = math.abs(math.sin(CurTime()) * 55) + 200 -- Effet de pulsation
        
        draw.SimpleText("IbizaRP - EXCLUSIF", "IbizaSubTitle", w/2, h/2, textColor, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    end
end

function PANEL:Paint(w, h)
    -- Effet de flou
    local x, y = self:LocalToScreen(0, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(blur)
    
    for i = 1, 3 do
        blur:SetFloat("$blur", (i / 3) * 4)
        blur:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(x * -1, y * -1, ScrW(), ScrH())
    end
    
    -- Fond texture bois avec effet
    surface.SetDrawColor(frameColor)
    surface.DrawRect(0, 0, w, h)
    
    -- Motifs de texture en filigrane
    for i = 0, h, 20 do
        surface.SetDrawColor(200, 180, 140, 10)
        surface.DrawLine(0, i, w, i)
    end
    
    -- Bordure arrondie
    surface.SetDrawColor(tanColor)
    surface.DrawOutlinedRect(0, 0, w, h, 3)
    
    -- �l�ments d�coratifs inspir�s de l'image
    draw.RoundedBox(8, w - 70, h - 70, 50, 50, greenColor)
    draw.SimpleText("B", "IbizaTitle", w - 45, h - 45, Color(200, 180, 100), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
    
    -- Effets suppl�mentaires
    local time = CurTime() * 2
    local size = math.sin(time) * 5 + 20
    draw.RoundedBox(8, 20, h - 70, size, size, Color(yellowColor.r, yellowColor.g, yellowColor.b, 150))
    
    -- Angle diagonal
    surface.SetDrawColor(210, 180, 140, 80)
    surface.DrawLine(0, 0, w, h)
    surface.DrawLine(w, 0, 0, h)
end

vgui.Register("IbizaRPContextMenu", PANEL, "DFrame")

-- Fonction pour afficher/masquer le menu
local menuPanel = nil

function ToggleContextMenu()
    if IsValid(menuPanel) then
        menuPanel:Close()
        menuPanel = nil
    else
        menuPanel = vgui.Create("IbizaRPContextMenu")
        menuPanel:MakePopup()
    end
end

-- Remplacement du menu contextuel par d�faut
hook.Add("ContextMenuOpen", "IbizaRPCustomContextMenu", function()
    ToggleContextMenu()
    return false -- Bloquer le menu contextuel par d�faut
end)

-- Mise � jour de l'argent en temps r�el
hook.Add("Think", "IbizaRPContextMenuMoneyUpdate", function()
    if IsValid(menuPanel) and LocalPlayer():getDarkRPVar("money") != playerInfo.money then
        playerInfo.money = LocalPlayer():getDarkRPVar("money") or 0
    end
end)

print("[IbizaRP] Menu contextuel charg�!")